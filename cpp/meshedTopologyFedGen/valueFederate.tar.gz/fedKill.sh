pkill -9 helics_broker 
pkill -9 valueFed
